/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { HeroSection } from './components/HeroSection.tsx';
import { MarqueeSection } from './components/MarqueeSection.tsx';
import { AboutSection } from './components/AboutSection.tsx';
import { ServicesSection } from './components/ServicesSection.tsx';
import { ProjectsSection, AIProjectItem } from './components/ProjectsSection.tsx';
import { ContactModal } from './components/ContactModal.tsx';
import { ArchitectureModal } from './components/ArchitectureModal.tsx';
import { FooterSection } from './components/FooterSection.tsx';

export default function App() {
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<AIProjectItem | null>(null);
  const [activeImage, setActiveImage] = useState<string | null>(null);

  const handleOpenContact = () => {
    setIsContactOpen(true);
  };

  const handleCloseContact = () => {
    setIsContactOpen(false);
  };

  const handleOpenProject = (project: AIProjectItem, imageSrc?: string) => {
    setSelectedProject(project);
    setActiveImage(imageSrc || project.col2Image);
  };

  const handleCloseProject = () => {
    setSelectedProject(null);
    setActiveImage(null);
  };

  return (
    <div
      className="relative w-full min-h-screen bg-[#0C0C0C] text-[#D7E2EA] font-['Kanit',sans-serif] selection:bg-[#B600A8] selection:text-white"
      style={{ overflowX: 'clip' }}
    >
      <main className="w-full flex flex-col" style={{ overflowX: 'clip' }}>
        {/* 1. HeroSection */}
        <HeroSection onOpenContact={handleOpenContact} onOpenProject={handleOpenProject} />

        {/* 2. MarqueeSection */}
        <MarqueeSection onOpenProject={handleOpenProject} />

        {/* 3. AboutSection */}
        <AboutSection onOpenContact={handleOpenContact} />

        {/* 4. ServicesSection (Capabilities) */}
        <ServicesSection />

        {/* 5. ProjectsSection (Architectures) */}
        <ProjectsSection onOpenProject={handleOpenProject} />

        {/* Footer */}
        <FooterSection onOpenContact={handleOpenContact} />
      </main>

      {/* Modals & Dialogs */}
      <ContactModal
        isOpen={isContactOpen}
        onClose={handleCloseContact}
      />

      <ArchitectureModal
        isOpen={!!selectedProject}
        project={selectedProject}
        activeImage={activeImage}
        onClose={handleCloseProject}
        onOpenContact={handleOpenContact}
      />
    </div>
  );
}
